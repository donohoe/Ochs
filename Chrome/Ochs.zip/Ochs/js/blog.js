console.log("Blog");

Ochs.pageType = "blog";
			
$("a[name='top']").css("display", "none !important");